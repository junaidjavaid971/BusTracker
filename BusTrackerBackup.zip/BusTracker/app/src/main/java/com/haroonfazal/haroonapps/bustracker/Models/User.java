package com.haroonfazal.haroonapps.bustracker.Models;

/**
 * Created by haroonpc on 3/12/2018.
 */

public class User
{
    public String name,email,password;

    public User(String name, String email, String password) {
        this.name = name;
        this.email = email;
        this.password = password;
    }
}
